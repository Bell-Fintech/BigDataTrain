package homework;

import java.util.Arrays;

public class User{
	//用户的游戏账号（比如： "朕御驾亲征痛杀之"）
	private String number;
	//用户所在的对局ID（比如： "艾欧尼亚-1001"）
	private int id;
	//用户所使用的英雄角色（比如： 易大师或者阿狸....）
	private String name;
	//所装配的装备（装备应该可以是多个，比如"无尽之刃"、"狂徒铠甲"等）
	String[] device={"无尽之刃","狂徒铠甲"};
	//用户助攻数
	private int helpNum;
	//用户所杀的人头数
	private int killNum;
	//斩杀小兵数
	private int killSmall;
	//用户的本局游戏实时得分（游戏得分=助攻数*10+击杀人头数*20+小兵数*2+装备件数*5）
	private int score;
	//用户的历史累计得分
	private int count=0;
	//用户的等级
	private int level;
	//同时，需要具备以下方法： 获取各属性值（如获取账号，对局ID等）设置各属性值（如设置账号，对局ID等）
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String[] getDevice() {
		return device;
	}
	public void setDevice(String[] device) {
		this.device = device;
	}
	public int getHelpNum() {
		return helpNum;
	}
	public void setHelpNum(int helpNum) {
		this.helpNum = helpNum;
	}
	public int getKillNum() {
		return killNum;
	}
	public void setKillNum(int killNum) {
		this.killNum = killNum;
	}
	public int getKillSmall() {
		return killSmall;
	}
	public void setKillSmall(int killSmall) {
		this.killSmall = killSmall;
	}
	public int getScore() {
		//用户的本局游戏实时得分（游戏得分=助攻数*10+击杀人头数*20+小兵数*2+装备件数*5）
		this.score=this.helpNum*10+this.killNum*20+this.killSmall*2+this.device.length*5;
		return score;
	}
	public int getCount() {
		//注：用户等级不应该直接设置，而是，根据当游戏历史总得分发生变化时，对象自动更新游戏等级
		count+=getScore();
		return count;
	}
	public int getLevel() {
		//注：用户等级不应该直接设置，而是，根据当游戏历史总得分发生变化时，对象自动更新游戏等级
		//等级规则如下： 累计得分---> [0-100]，等级   累计得分---> [101-200]，等级2   以此类推，最高等级为30级
		if(this.getCount()/101>=0&&this.level<31)
			this.level=this.getCount()/101+1;
		return level;
	}
	@Override
	public String toString() {
		return "User [number=" + number + ", id=" + id + ", name=" + name + ", device=" + Arrays.toString(device)
				+ ", helpNum=" + helpNum + ", killNum=" + killNum + ", killSmall=" + killSmall + ", score=" + score
				+ ", count=" + count + ", level=" + level + "]";
	}
	
	public User() {
	}
	public User(String number, int id, String name, String[] device, int helpNum, int killNum, int killSmall, int score,
			int count, int level) {
		this.number = number;
		this.id = id;
		this.name = name;
		this.device = device;
		this.helpNum = helpNum;
		this.killNum = killNum;
		this.killSmall = killSmall;
		this.score = score;
		this.count = count;
		this.level = level;
	}
	
}
