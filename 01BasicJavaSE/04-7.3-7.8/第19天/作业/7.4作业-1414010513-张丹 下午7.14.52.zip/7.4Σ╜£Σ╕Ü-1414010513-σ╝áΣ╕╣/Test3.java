package homework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/*
 * 有如下信息
学号，姓名，年龄，总分
173620,王康,22,470
173623,刘明,22,450
173628,王瑞,20,460
173624,李玉,21,432
173622,李倩,24,480
173634,刘军,23,550
173632,刘向,20,650

将文件中的数据存入到ArrayList<Student>中，然后分别按照优先级学号、年龄、总分进行排序输出
*/
public class Test3 {
	public static void main(String[] args) {
	    ArrayList<Student> list = new ArrayList<Student>();
		list.add(new Student(173620,"王康", 22,470));
		list.add(new Student(173623,"刘明", 22,450));
		list.add(new Student(173628,"王瑞", 20,460));
		list.add(new Student(173624,"李玉", 21,432));
		list.add(new Student(173622,"李倩", 24,480));
		list.add(new Student(173634,"刘军", 23,550));
		list.add(new Student(173632,"刘向" ,20,650));
		// 升序：以姓名排序，如果姓名相同再以年龄排序
		// 降序：以年龄排序，如果年龄相同再以姓名排序
		//列表中的所有元素都必须实现 Comparable 接口
		Collections.sort(list);
		for (Student p : list) {
			System.out.println(p);
		}
		
}
}
