package homework;

import java.util.ArrayList;

//定义一个ArrayList<Student> ，放入3个Student对象，
//然后计算出list中所有Student对象的平均分及平均年龄，并将结果打印到控制台
public class Test1 {
	public static void main(String[] args) {
		ArrayList<Student> list=new ArrayList<Student>();
		list.add(new Student(18,99));
		list.add(new Student(19,98));
		list.add(new Student(20,100));
		
		int aveAge=0,sumAge=0,aveScore=0,sumScore=0;
		for(int i=0;i<list.size();i++){
			sumAge+=list.get(i).getAge();
			sumScore+=list.get(i).getScore();
		}
		aveAge=sumAge/list.size();
		aveScore=sumScore/list.size();
		System.out.println("平均年龄为:"+aveAge+";平均成绩为:"+aveScore);
	}

}
