package homework;

public class Student implements Comparable<Student>{
	private int age;
	private int score;
	private int num;
	private String name;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Student() {
	}

	public Student(int age, int score) {
		super();
		this.age = age;
		this.score = score;
	}
	public Student( int num, String name,int age, int score) {
		this.age = age;
		this.score = score;
		this.num = num;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [num=" + num+", age=" + age + ", score=" + score +  ", name=" + name+"]";
	}
	@Override
	public int compareTo(Student o) {
		 // 升序：以学号排序，如果学号相同再以年龄排序；如果年龄相同再以总分排序
		 //return  this.num==o.num?(this.age==o.age?this.age-o.age:this.score-o.score):this.num-o.num;
		 // 降序：以学号排序，如果学号相同再以年龄排序；如果年龄相同再以总分排序
		 return  o.num==this.num?(o.age==this.age?o.age-this.age:o.score-this.score):o.num-this.num;
	}	
}
