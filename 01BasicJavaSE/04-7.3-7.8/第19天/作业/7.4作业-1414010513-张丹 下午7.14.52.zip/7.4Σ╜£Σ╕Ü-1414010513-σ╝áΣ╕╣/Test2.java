package homework;
public class Test2 {
	/*
	需求：在程序中创建一个游戏用户对象
	然后修改该用户对象的各个能直接修改的属性值
	然后查看该用户的当前状态（即对象中的所有当前属性值）
	*/
	public static void main(String[] args) {
		User user=new User();
		user.setNumber("朕御驾亲征痛杀之");
		user.setId(1001);
		user.setName("易大师");
		String[] device={"无尽之刃","狂徒铠甲"};
		user.setDevice(device);
		user.setHelpNum(4);
		user.setKillNum(2);
		user.setKillSmall(5);
		user.getScore();
		user.getCount();
		user.getLevel();
		System.out.println(user);
	}
}
