package homework;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
public class Test2 {
	public static void main(String[] args) {
		/*1.Map集合嵌套List集合。
		 */
		ArrayList<String> list = new ArrayList<String>();
		Map<String, ArrayList<String>> map1 = new LinkedHashMap<String, ArrayList<String>>();
		Map<String, Map<String, ArrayList<String>>> map = new LinkedHashMap<String, Map<String, ArrayList<String>>>();
		ArrayList<String> list1 = new ArrayList<String>();
		list.add("朝阳区");
		list.add("昌平区");
		list.add("通州区");
		list.add("大兴区");
		list.add("密云区");
		list.add("东城区");
		map1.put("北京市", list);
		map.put("北京省", map1);
		
		list = new ArrayList<String>();
		list1 = new ArrayList<String>();
		map1 = new LinkedHashMap<String, ArrayList<String>>();
		list.add("瑶海区");
		list.add("包河区");
		list.add("蜀山区");
		list1.add("金安区");
		list1.add("裕安区");
		map1.put("合肥市",list);
		map1.put("六安市",list1);
		map.put("安徽省", map1);
		
		list = new ArrayList<String>();
		list1 = new ArrayList<String>();
		map1 = new LinkedHashMap<String, ArrayList<String>>();
		list.add("鱼花台区");
		list.add("浦口区");
		list.add("江宁区");
		list1.add("锡山区");
		list1.add("滨湖区");
		list1.add("惠山区");
		map1.put("南京市",list);
		map1.put("无锡市", list1);
		map.put("江苏省", map1);

		for (Entry<String, Map<String, ArrayList<String>>> entry : map.entrySet()) {
			String key = entry.getKey();
			System.out.println(key);
			for (Entry<String, ArrayList<String>> entry1 : entry.getValue().entrySet()) {
				String key1 = entry1.getKey();
				System.out.println("	"+key1);
			
				// 遍历ArrayList里面的内容
				ArrayList  list2 = entry1.getValue();
				Iterator iterator=list2.iterator();
				while (iterator.hasNext()) {
					System.out.println("		" + iterator.next());
				}
//				for (String v : value) {
//					System.out.println("	" + v);
//				}
		}
	}
	}
}
