package homework;

import java.util.LinkedHashSet;
import java.util.Random;

//1.	使用一个容器存储0-1000数值中的999个数值，要求这999个数是不重复值。
//最后求出0-1000这些个数中哪两个数不存在容器中

public class Test1 {
	public static void main(String[] args) {
		LinkedHashSet<Integer> hashSet = new LinkedHashSet<>();
		Random random = new Random();
		while(true){
			int i = random.nextInt(1001);
			hashSet.add(i);
			if(hashSet.size()==999){
				break;
			}
		}
		LinkedHashSet<Integer> hashSet1 = new LinkedHashSet<Integer>();
		for(int i=0;i<1001;i++){
			hashSet1.add(i);
		}
		hashSet1.removeAll(hashSet);
		System.out.println(hashSet1);
	}
}
